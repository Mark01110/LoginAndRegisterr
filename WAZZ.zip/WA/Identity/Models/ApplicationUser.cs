﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [ProtectedPersonalData]
        [Display(Name = "First name")]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [ProtectedPersonalData]
        [Display(Name = "Last name")]
        public string LastName { get; set; } = string.Empty;
    }
}
